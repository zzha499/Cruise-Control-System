#define PedalsMin 3.0
#define SpeedMin 30.0
#define SpeedMax 150.0
#define SpeedInc 2.5

float regulateThrottle(int isGoingon, float cruiseSpeed, float vehicleSpeed);

#include <stdbool.h>
