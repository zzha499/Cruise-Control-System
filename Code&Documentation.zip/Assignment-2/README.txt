COMPSYS 723 Assigment 2
Group 26 - Eric Zhao, Adam Wilson


This folder contains Group 26s 2021 Assignment 2
Compile the code using 'make cruise.xes'
Run the simulation using './cruise.xes'

All our Esterel code is contained within cruise.strl
This folder also contains our report, context diagrams and project review
